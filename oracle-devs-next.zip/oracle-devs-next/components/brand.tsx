import Link from "next/link";

export function OracleMark({ compact = false }: { compact?: boolean }) {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true" className={compact ? "h-8 w-8" : "h-11 w-11"}>
      <defs>
        <linearGradient id="odg" x1="0" x2="1">
          <stop offset="0" stopColor="#60a5fa" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <path d="M32 5v54M14 16l18-11 18 11v32L32 59 14 48z" fill="none" stroke="url(#odg)" strokeWidth="4" />
      <path d="M23 21l9 6 9-6M23 43l9-6 9 6M20 32h9M35 32h9" fill="none" stroke="#dbeafe" strokeWidth="3" strokeLinecap="round" />
      <circle cx="32" cy="32" r="4" fill="#60a5fa" />
    </svg>
  );
}

export function Brand({ href = "/", compact = false }: { href?: string; compact?: boolean }) {
  return (
    <Link href={href} className="flex items-center gap-3">
      <OracleMark compact={compact} />
      <span className="leading-none">
        <span className="block text-lg font-extrabold tracking-tight text-white">ORACLE</span>
        <span className="block text-xs font-medium tracking-[0.45em] text-slate-400">DEVS</span>
      </span>
    </Link>
  );
}
