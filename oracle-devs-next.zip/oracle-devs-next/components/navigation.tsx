"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bell, Compass, Home, PlusSquare, UserRound } from "lucide-react";
import { Brand } from "@/components/brand";

const items = [
  { href: "/", label: "Accueil", icon: Home },
  { href: "/explore", label: "Explorer", icon: Compass },
  { href: "/publish", label: "Publier", icon: PlusSquare },
  { href: "/notifications", label: "Alertes", icon: Bell },
  { href: "/profile", label: "Profil", icon: UserRound }
];

export function Navigation() {
  const pathname = usePathname();
  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 hidden h-16 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl md:block">
        <div className="mx-auto flex h-full max-w-7xl items-center px-6">
          <Brand />
          <nav className="ml-10 flex items-center gap-1">
            {items.map(({ href, label, icon: Icon }) => {
              const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
              return (
                <Link key={href} href={href} className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition ${active ? "bg-slate-800/80 text-white" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}>
                  <Icon className="h-4 w-4" />{label}
                </Link>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/auth" className="rounded-lg border border-blue-500/30 bg-blue-500/10 px-4 py-2 text-sm font-semibold text-blue-300 hover:bg-blue-500/15">Connexion</Link>
          </div>
        </div>
      </header>

      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-50 flex h-16 border-t border-slate-800/80 bg-slate-950/95 backdrop-blur-xl md:hidden">
        {items.map(({ href, label, icon: Icon }) => {
          const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <Link key={href} href={href} className={`flex flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium ${active ? "text-blue-400" : "text-slate-500"}`}>
              <Icon className="h-5 w-5" />{label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
