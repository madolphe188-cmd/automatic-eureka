import Link from "next/link";
import { Eye, MessageSquare, Star } from "lucide-react";

export type ShareCard = {
  id: string;
  title: string;
  description: string | null;
  url: string;
  ai_name: string | null;
  category: string | null;
  tags: string[];
  created_at: string;
};

export function ResourceCard({ resource }: { resource: ShareCard }) {
  return (
    <Link href={`/share/${resource.id}`} className="group glass flex min-h-60 flex-col rounded-2xl p-5 transition hover:-translate-y-1 hover:border-blue-500/30 hover:bg-slate-800/50 hover:shadow-[0_15px_35px_rgba(59,130,246,.1)]">
      <div className="mb-4 flex items-start justify-between gap-3">
        <span className="rounded-full border border-blue-500/20 bg-blue-500/10 px-2.5 py-1 text-xs font-semibold text-blue-300">{resource.ai_name || "IA"}</span>
        <span className="flex items-center gap-1 text-xs font-semibold text-slate-400"><Star className="h-3.5 w-3.5 text-blue-400" /> Ressource</span>
      </div>
      <h3 className="mb-2 line-clamp-2 text-lg font-bold text-slate-100 transition group-hover:text-blue-300">{resource.title}</h3>
      <p className="mb-5 line-clamp-3 flex-1 text-sm leading-6 text-slate-400">{resource.description || "Ressource partagée par la communauté ORACLE DEVS."}</p>
      <div className="mb-4 flex flex-wrap gap-2">
        {(resource.tags || []).slice(0, 4).map(tag => <span key={tag} className="rounded-md border border-slate-700 bg-slate-900/70 px-2 py-1 text-[11px] text-slate-300">#{tag}</span>)}
      </div>
      <div className="flex items-center justify-between border-t border-slate-800 pt-4 text-xs text-slate-500">
        <span>{resource.category || "Développement"}</span>
        <span className="flex items-center gap-3"><span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> public</span><MessageSquare className="h-3.5 w-3.5" /></span>
      </div>
    </Link>
  );
}
