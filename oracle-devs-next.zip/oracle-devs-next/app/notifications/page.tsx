import { redirect } from "next/navigation";
import { Bell } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function NotificationsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth?next=/notifications");
  const { data } = await supabase.from("notifications").select("id,type,message,is_read,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(50);
  return <section className="mx-auto max-w-2xl pt-6"><h1 className="mb-7 flex items-center gap-3 text-2xl font-black text-white"><Bell className="h-6 w-6 text-blue-400" /> Notifications</h1><div className="space-y-3">{(data ?? []).length ? data?.map(n => <div key={n.id} className={`rounded-2xl border p-4 ${n.is_read ? "border-slate-800 bg-slate-900/30" : "border-blue-500/20 bg-blue-500/5"}`}><p className="text-sm text-slate-200">{n.message}</p><p className="mt-2 text-xs text-slate-500">{new Date(n.created_at).toLocaleString("fr-FR")}</p></div>) : <div className="glass rounded-2xl p-8 text-center text-slate-400">Aucune notification.</div>}</div></section>;
}
