import { redirect } from "next/navigation";
import { ShieldAlert, Users, Terminal, Video } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth?next=/admin");
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "admin") return <section className="pt-10"><div className="glass rounded-3xl p-8 text-center"><ShieldAlert className="mx-auto h-8 w-8 text-red-400" /><h1 className="mt-4 text-2xl font-black text-white">Accès administrateur requis</h1><p className="mt-2 text-slate-400">Ton compte n’a pas encore le rôle admin.</p></div></section>;

  const [{ count: users }, { count: shares }, { count: reports }, { count: videos }] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("shares").select("id", { count: "exact", head: true }),
    supabase.from("reports").select("id", { count: "exact", head: true }).eq("status", "open"),
    supabase.from("videos").select("id", { count: "exact", head: true })
  ]);

  const cards = [[Users, "Utilisateurs", users], [Terminal, "Partages", shares], [ShieldAlert, "Signalements ouverts", reports], [Video, "Vidéos", videos]] as const;
  return <section className="pt-6"><div className="mb-8"><p className="text-xs font-bold uppercase tracking-[0.25em] text-violet-400">Administration</p><h1 className="mt-2 text-3xl font-black text-white">ORACLE DEVS Admin</h1></div><div className="grid gap-5 md:grid-cols-4">{cards.map(([Icon, label, count]) => <div key={label} className="glass rounded-2xl p-5"><Icon className="h-5 w-5 text-blue-400" /><p className="mt-4 text-sm text-slate-400">{label}</p><p className="mt-1 text-3xl font-black text-white">{count ?? 0}</p></div>)}</div></section>;
}
