import { notFound } from "next/navigation";
import { ExternalLink, Tag } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function ShareDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: share } = await supabase
    .from("shares")
    .select("id,title,description,url,ai_name,category,tags,status,created_at")
    .eq("id", id)
    .maybeSingle();

  if (!share || share.status !== "published") notFound();

  return (
    <article className="mx-auto max-w-4xl pt-6">
      <div className="glass overflow-hidden rounded-3xl">
        <div className="border-b border-slate-800 p-7 md:p-9">
          <div className="mb-5 flex flex-wrap items-center gap-3">
            <span className="rounded-full border border-blue-500/20 bg-blue-500/10 px-3 py-1 text-xs font-semibold text-blue-300">{share.ai_name || "IA"}</span>
            <span className="rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs text-slate-300">{share.category || "Développement"}</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight text-white md:text-5xl">{share.title}</h1>
          <p className="mt-5 max-w-3xl text-base leading-7 text-slate-400">{share.description || "Aucune description fournie."}</p>
        </div>
        <div className="space-y-8 p-7 md:p-9">
          {share.tags?.length ? <div><h2 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-200"><Tag className="h-4 w-4 text-blue-400" /> Tags</h2><div className="flex flex-wrap gap-2">{share.tags.map(tag => <span key={tag} className="rounded-md border border-slate-700 bg-slate-950/70 px-2.5 py-1 text-xs text-slate-300">#{tag}</span>)}</div></div> : null}
          <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5"><p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Lien de la ressource</p><p className="break-all font-mono text-sm text-slate-300">{share.url}</p><a href={share.url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-3 text-sm font-bold text-white"><ExternalLink className="h-4 w-4" /> Ouvrir la ressource</a></div>
          <p className="text-xs text-slate-600">Publié le {new Date(share.created_at).toLocaleDateString("fr-FR")}</p>
        </div>
      </div>
    </article>
  );
}
