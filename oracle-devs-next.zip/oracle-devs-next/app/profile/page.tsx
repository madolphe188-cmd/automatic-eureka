import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ProfilePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth?next=/profile");
  const { data: profile } = await supabase.from("profiles").select("username,display_name,bio,role,created_at").eq("id", user.id).maybeSingle();
  return <section className="mx-auto max-w-3xl pt-6"><div className="glass rounded-3xl p-8"><div className="mb-6"><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-400">Profil</p><h1 className="mt-2 text-3xl font-black text-white">{profile?.display_name || "Développeur"}</h1><p className="mt-1 text-blue-300">@{profile?.username || "utilisateur"}</p></div><p className="leading-7 text-slate-400">{profile?.bio || "Bienvenue dans ORACLE DEVS."}</p><div className="mt-7 grid gap-3 sm:grid-cols-2"><div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><p className="text-xs text-slate-500">Rôle</p><p className="mt-1 font-semibold text-white">{profile?.role || "user"}</p></div><div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><p className="text-xs text-slate-500">Membre depuis</p><p className="mt-1 font-semibold text-white">{profile?.created_at ? new Date(profile.created_at).toLocaleDateString("fr-FR") : "—"}</p></div></div></div></section>;
}
