import Link from "next/link";
import { ArrowRight, Code2, Cpu, Search, Sparkles, Terminal } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { ResourceCard, type ShareCard } from "@/components/resource-card";
import { Brand } from "@/components/brand";

export default async function HomePage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("shares")
    .select("id,title,description,url,ai_name,category,tags,created_at")
    .eq("status", "published")
    .order("created_at", { ascending: false })
    .limit(6);

  const shares = (data ?? []) as ShareCard[];

  return (
    <div className="space-y-12 pt-3">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-800 bg-slate-900/30 px-6 py-16 text-center md:px-12 md:py-24">
        <div className="grid-bg absolute inset-0" />
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-blue-500/10 blur-[100px]" />
        <div className="absolute -bottom-28 -left-24 h-72 w-72 rounded-full bg-violet-500/10 blur-[100px]" />
        <div className="relative mx-auto max-w-4xl">
          <div className="mb-7 flex justify-center"><Brand compact /></div>
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-500/10 px-4 py-2 text-xs font-semibold text-blue-300"><Sparkles className="h-4 w-4" /> ORACLE DEVS</div>
          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl">La communauté des développeurs augmentés par l’IA</h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-slate-400 md:text-lg">Découvrez des prompts, chats IA, ressources et astuces de développement partagés par la communauté.</p>
          <div className="mx-auto mt-9 flex max-w-2xl items-center rounded-full border border-slate-700/80 bg-slate-950/80 p-2 shadow-2xl backdrop-blur-xl">
            <Search className="ml-3 h-5 w-5 text-slate-500" />
            <input className="min-w-0 flex-1 bg-transparent px-3 py-3 text-sm text-slate-200 outline-none" placeholder="Rechercher un prompt, un chat IA, une ressource..." />
            <Link href="/explore" className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-3 text-sm font-bold text-white">Chercher</Link>
          </div>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/explore" className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-7 py-3 text-sm font-bold text-white">Explorer</Link>
            <Link href="/publish" className="rounded-full border border-slate-700 bg-slate-900/80 px-7 py-3 text-sm font-semibold text-slate-200 hover:bg-slate-800">Partager une ressource</Link>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          [Code2, "Développement", "Prompts et ressources pratiques pour coder plus vite."],
          [Cpu, "IA & outils", "Comparez les usages de ChatGPT, Claude, Cursor et autres outils."],
          [Terminal, "Communauté", "Publiez, commentez, aimez et faites remonter les meilleures ressources."]
        ].map(([Icon, title, text]) => {
          const I = Icon as typeof Code2;
          return <div key={String(title)} className="glass rounded-2xl p-5"><I className="mb-4 h-6 w-6 text-blue-400" /><h2 className="font-bold text-white">{title as string}</h2><p className="mt-2 text-sm leading-6 text-slate-400">{text as string}</p></div>;
        })}
      </section>

      <section>
        <div className="mb-6 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-400">Découvrir</p><h2 className="mt-2 text-2xl font-bold text-white">Derniers partages</h2></div><Link href="/explore" className="flex items-center gap-1 text-sm font-semibold text-blue-300">Voir tout <ArrowRight className="h-4 w-4" /></Link></div>
        {shares.length ? <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{shares.map(s => <ResourceCard key={s.id} resource={s} />)}</div> : <div className="glass rounded-2xl p-8 text-center text-slate-400">Aucune ressource publiée pour le moment. La première publication peut être la tienne.</div>}
      </section>
    </div>
  );
}
