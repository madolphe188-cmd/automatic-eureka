"use client";

import { FormEvent, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Mail, Lock, UserRound } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Brand } from "@/components/brand";

export default function AuthPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setMessage("");
    const supabase = createClient();
    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage(error.message); else router.replace(searchParams.get("next") || "/");
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
      if (error) setMessage(error.message); else if (data.session) router.replace("/"); else setMessage("Compte créé. Vérifie ton e-mail si la confirmation est activée.");
    }
    setBusy(false);
  }

  return <div className="grid min-h-[75vh] place-items-center pt-6"><div className="w-full max-w-md"><div className="mb-7 flex justify-center"><Brand /></div><div className="glass rounded-3xl p-7 shadow-2xl"><div className="mb-7"><h1 className="text-2xl font-black text-white">{mode === "login" ? "Bon retour" : "Rejoins ORACLE DEVS"}</h1><p className="mt-2 text-sm text-slate-400">{mode === "login" ? "Connecte-toi pour publier et interagir." : "Crée ton espace développeur."}</p></div><form onSubmit={onSubmit} className="space-y-4">{mode === "signup" && <label className="block"><span className="mb-2 block text-sm text-slate-300">Nom affiché</span><div className="relative"><UserRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><input value={displayName} onChange={e => setDisplayName(e.target.value)} required className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-10 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="Ton nom" /></div></label>}<label className="block"><span className="mb-2 block text-sm text-slate-300">E-mail</span><div className="relative"><Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><input value={email} onChange={e => setEmail(e.target.value)} required type="email" className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-10 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="toi@example.com" /></div></label><label className="block"><span className="mb-2 block text-sm text-slate-300">Mot de passe</span><div className="relative"><Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><input value={password} onChange={e => setPassword(e.target.value)} required minLength={6} type="password" className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-10 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="••••••••" /></div></label><button disabled={busy} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 py-3 font-bold text-white disabled:opacity-50">{busy ? "Traitement..." : mode === "login" ? "Se connecter" : "Créer mon compte"}</button></form>{message && <p className="mt-4 rounded-xl border border-blue-500/20 bg-blue-500/10 p-3 text-sm text-blue-200">{message}</p>}<button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setMessage(""); }} className="mt-6 w-full text-center text-sm text-slate-400 hover:text-white">{mode === "login" ? "Pas encore de compte ? S'inscrire" : "Déjà membre ? Se connecter"}</button></div></div></div>;
}
