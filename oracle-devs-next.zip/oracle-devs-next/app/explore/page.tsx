import { createClient } from "@/lib/supabase/server";
import { ResourceCard, type ShareCard } from "@/components/resource-card";

export default async function ExplorePage() {
  const supabase = await createClient();
  const { data } = await supabase.from("shares").select("id,title,description,url,ai_name,category,tags,created_at").eq("status", "published").order("created_at", { ascending: false }).limit(60);
  const shares = (data ?? []) as ShareCard[];

  return <section className="pt-6"><div className="mb-8"><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-400">Explorer</p><h1 className="mt-2 text-3xl font-black text-white">Ressources de la communauté</h1><p className="mt-2 max-w-2xl text-slate-400">Recherche et découverte des partages publiés sur ORACLE DEVS.</p></div>{shares.length ? <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{shares.map(s => <ResourceCard key={s.id} resource={s} />)}</div> : <div className="glass rounded-2xl p-8 text-center text-slate-400">Aucune ressource publiée.</div>}</section>;
}
