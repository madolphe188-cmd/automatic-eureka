"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function PublishPage() {
  const router = useRouter();
  const [form, setForm] = useState({ title: "", description: "", url: "", ai_name: "ChatGPT", category: "Prompts", tags: "" });
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push("/auth?next=/publish"); return; }
    const { error } = await supabase.from("shares").insert({ author_id: user.id, title: form.title, description: form.description, url: form.url, ai_name: form.ai_name, category: form.category, tags: form.tags.split(",").map(x => x.trim()).filter(Boolean) });
    if (error) setMessage(error.message); else router.push("/explore");
    setBusy(false);
  }

  return <section className="mx-auto max-w-3xl pt-6"><div className="mb-7"><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-400">Publication</p><h1 className="mt-2 text-3xl font-black text-white">Partager une ressource</h1><p className="mt-2 text-slate-400">Ajoute un lien de chat IA, un prompt ou une ressource utile.</p></div><form onSubmit={submit} className="glass space-y-5 rounded-3xl p-7"><label className="block"><span className="mb-2 block text-sm text-slate-300">Titre</span><input required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="Ex. Architecte Next.js avec Claude" /></label><div className="grid gap-5 md:grid-cols-2"><label className="block"><span className="mb-2 block text-sm text-slate-300">Plateforme IA</span><select value={form.ai_name} onChange={e => setForm({ ...form, ai_name: e.target.value })} className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none"><option>ChatGPT</option><option>Claude</option><option>Cursor</option><option>Gemini</option><option>Grok</option><option>DeepSeek</option><option>Autre</option></select></label><label className="block"><span className="mb-2 block text-sm text-slate-300">Catégorie</span><select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none"><option>Prompts</option><option>Frontend</option><option>Backend</option><option>IA</option><option>DevOps</option><option>IoT</option><option>UI/UX</option></select></label></div><label className="block"><span className="mb-2 block text-sm text-slate-300">Lien</span><input required type="url" value={form.url} onChange={e => setForm({ ...form, url: e.target.value })} className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="https://..." /></label><label className="block"><span className="mb-2 block text-sm text-slate-300">Description</span><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={4} className="w-full resize-y rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="Explique à quoi sert la ressource..." /></label><label className="block"><span className="mb-2 block text-sm text-slate-300">Tags</span><input value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} className="w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-slate-200 outline-none focus:border-blue-500" placeholder="Next.js, Supabase, RLS" /></label>{message && <p className="rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-200">{message}</p>}<button disabled={busy} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 py-3 font-bold text-white disabled:opacity-50">{busy ? "Publication..." : "Publier la ressource"}</button></form></section>;
}
