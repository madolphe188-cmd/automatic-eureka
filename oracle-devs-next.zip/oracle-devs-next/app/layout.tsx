import type { Metadata } from "next";
import "./globals.css";
import { Navigation } from "@/components/navigation";

export const metadata: Metadata = {
  title: "ORACLE DEVS — Communauté de développeurs",
  description: "Partagez et découvrez des chats IA, prompts, ressources et astuces de développement."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>
        <Navigation />
        <main className="mx-auto min-h-screen max-w-7xl px-4 pb-24 pt-20 md:px-8 md:pb-10">{children}</main>
      </body>
    </html>
  );
}
