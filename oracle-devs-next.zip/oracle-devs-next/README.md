# ORACLE DEVS — Next.js + Supabase

Socle frontend du projet ORACLE DEVS, basé sur Next.js App Router, Tailwind CSS v4 et Supabase SSR.

## 1. Préparer les variables

Copie `.env.example` vers `.env.local` et renseigne :

```env
NEXT_PUBLIC_SUPABASE_URL=https://lhifzaphwlxmhlooivgu.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```

La clé doit être la **publishable key** du projet Supabase, jamais une `service_role`/secret key.

## 2. Installer

```bash
npm install
npm run typecheck
npm run dev
```

## 3. Routes déjà préparées

- `/` accueil ORACLE DEVS
- `/explore` exploration des ressources publiées
- `/auth` connexion / inscription
- `/publish` publication d'une ressource
- `/profile` profil utilisateur
- `/notifications` notifications
- `/admin` tableau de bord administrateur

## 4. Base Supabase

Le projet Supabase contient déjà les tables principales et RLS pour :
`profiles`, `shares`, `comments`, `likes`, `notifications`, `reports`, `videos`.

Un trigger crée automatiquement le profil public lors d'une inscription Auth.

## 5. Mise en ligne Vercel

Importer le dossier dans GitHub, puis connecter le dépôt à Vercel.
Dans Vercel > Settings > Environment Variables, renseigner les deux variables Supabase ci-dessus pour Production, Preview et Development.

## 6. Première étape après déploiement

Créer un compte via `/auth`. Le trigger Supabase crée le profil automatiquement. Le compte administrateur devra ensuite être promu au rôle `admin` dans `public.profiles` depuis un environnement administrateur sécurisé.
