# ORACLE DEVS — État Supabase

Projet Supabase : `lhifzaphwlxmhlooivgu`
Région : `eu-west-1`
PostgreSQL : 17.11

## Tables

- profiles
- shares
- comments
- likes
- notifications
- reports
- videos

Toutes les tables publiques ont RLS activé.

## Sécurité déjà appliquée

- contrôle admin via `private.is_admin()`
- fonction Auth de création automatique de profil via `private.handle_new_user()`
- trigger `on_auth_user_created`
- index des clés étrangères signalées par le conseiller Supabase
- optimisation des appels `auth.uid()` dans les policies avec `(select auth.uid())`
- anciennes fonctions SECURITY DEFINER publiques inutiles retirées/bloquées

Le conseiller sécurité Supabase retourne actuellement **0 finding**.

## Admin

Aucun profil utilisateur n'existait au moment de la configuration. Le premier compte doit être créé via Supabase Auth / l'interface ORACLE DEVS, puis son profil pourra être promu `admin` depuis un environnement administrateur sécurisé.
