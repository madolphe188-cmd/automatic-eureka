export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; username: string | null; display_name: string | null; avatar_url: string | null; bio: string | null; role: string; created_at: string; updated_at: string };
        Insert: Partial<Database["public"]["Tables"]["profiles"]["Row"]> & { id: string };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Row"]>;
        Relationships: [];
      };
      shares: {
        Row: { id: string; author_id: string; title: string; description: string | null; url: string; ai_name: string | null; category: string | null; tags: string[]; status: string; created_at: string; updated_at: string };
        Insert: { id?: string; author_id: string; title: string; description?: string | null; url: string; ai_name?: string | null; category?: string | null; tags?: string[]; status?: string; created_at?: string; updated_at?: string };
        Update: Partial<Database["public"]["Tables"]["shares"]["Insert"]>;
        Relationships: [{ foreignKeyName: "shares_author_id_fkey"; columns: ["author_id"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] }];
      };
      comments: {
        Row: { id: string; share_id: string; author_id: string; content: string; created_at: string; updated_at: string };
        Insert: { id?: string; share_id: string; author_id: string; content: string; created_at?: string; updated_at?: string };
        Update: Partial<Database["public"]["Tables"]["comments"]["Insert"]>;
        Relationships: [];
      };
      likes: {
        Row: { id: string; share_id: string; user_id: string; created_at: string };
        Insert: { id?: string; share_id: string; user_id: string; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["likes"]["Insert"]>;
        Relationships: [];
      };
      notifications: {
        Row: { id: string; user_id: string; type: string; message: string; share_id: string | null; actor_id: string | null; is_read: boolean; created_at: string };
        Insert: { id?: string; user_id: string; type: string; message: string; share_id?: string | null; actor_id?: string | null; is_read?: boolean; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["notifications"]["Insert"]>;
        Relationships: [];
      };
      reports: {
        Row: { id: string; share_id: string | null; comment_id: string | null; reporter_id: string; reason: string; details: string | null; status: string; created_at: string };
        Insert: { id?: string; share_id?: string | null; comment_id?: string | null; reporter_id: string; reason: string; details?: string | null; status?: string; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["reports"]["Insert"]>;
        Relationships: [];
      };
      videos: {
        Row: { id: string; title: string; youtube_url: string; description: string | null; position: number; active: boolean; created_at: string; updated_at: string };
        Insert: { id?: string; title: string; youtube_url: string; description?: string | null; position?: number; active?: boolean; created_at?: string; updated_at?: string };
        Update: Partial<Database["public"]["Tables"]["videos"]["Insert"]>;
        Relationships: [];
      };
    };
  };
};
